import React from 'react';

function Header() {
  return (
    <header>
      <h1>Fiji Airways Walk-In Queue</h1>
    </header>
  );
}

export default Header;
