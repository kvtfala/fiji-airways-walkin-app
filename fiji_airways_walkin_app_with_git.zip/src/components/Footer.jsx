import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; 2025 Fiji Airways. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
